let circleY = [0, 0, 0, 0, 0, 0, 0];

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(128,128,0);
  
  //Arrays for snow
  fill(255,255,255);
  circle(100, circleY[0], 25);
  circle(200, circleY[1], 40);
  circle(300, circleY[2], 15);
  circle(400, circleY[3], 30);
  circle(500, circleY[4], 25);
  circle(50, circleY[5], 20);
  circle(550, circleY[6], 20);

  circleY[0]++;
  circleY[1] += 2;
  circleY[2] += 1;
  circleY[3] += 2;
  circleY[4] += 1;
  circleY[5] += 3;
  circleY[6] += 3;
  
  if (circleY[0] > height) {
    circleY[0] = 0;
  }
  if (circleY[1] > height) {
    circleY[1] = 0;
  }
  if (circleY[2] > height) {
    circleY[2] = 0;
  }
  if (circleY[3] > height) {
    circleY[3] = 0;
  }
  if (circleY[4] > height) {
    circleY[4] = 0;
  }
  if (circleY[5] > height) {
    circleY[5] = 0;
  }
  if (circleY[6] > height) {
    circleY[6] = 0;
  }
  
  //snow on the ground 
  fill(255,255,255);
  rect(0,500,600,100);
  
  //trees
  fill(60,30,0);
  rect(145,360,65,180);
  fill(60,30,0);
  rect(500,400,40,180);
  fill(128,110,0);
  circle(180,300,150);
  fill(128,110,100);
  circle(520,420,110);
  
  
}