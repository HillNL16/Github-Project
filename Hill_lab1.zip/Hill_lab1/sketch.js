function setup() {
  createCanvas(499, 499);
  }

function draw() {
  background(51);
  
  
 
  //UFO shape
  strokeWeight(10);
  rect(262,330,150,50,100);
  describe('white rect with black outline and round edges in bottom right of canvas ');
  ellipse(335,300,80,50);
  strokeWeight(5);
  line(310,280,290,250);
  line(380,250,360,280);
  strokeWeight(7);
  ellipse(300,420,15,70);
  ellipse(375,420,15,70);
  point(338,356);
  point(300,356);
  point(375,356);
  strokeWeight(20);
  point(338,300); 
  
  //stars
  strokeWeight(10);
  point(100,100);
  point(300,50);
  strokeWeight(5);
  point(250,300);
  point(120,400); 
  point(250,250);
  point(100,230);
  point(450,450);
  point(200,100);
  point(50,480);
  point(25,180);
  point(200,100);
  point(480,25);
  point(465,260);
  point(150,350);
  strokeWeight(10);
  point(100,150);
  point(387,150);
  point(75,400);
  point(170,25);
  point(472,186);
  point(75,300);
  
  //planets 
  strokeWeight(15);
  line (75,150,50,50);
  strokeWeight(10);
  ellipse(65,100,75,75);
  strokeWeight(5);
  line(200,450,175,480);
  ellipse(188,466,20,20);
  strokeWeight(0);
  ellipse(400,100,50,50);
  strokeWeight(7);
  line(365,60,440,140);
  strokeWeight(0);
  ellipse(190,190,50,50);
  strokeWeight(4);
  line(155,155,230,230);
  
  //ship smoke
  strokeWeight(3);
  strokeJoin(MITER);
  beginShape();
  vertex(399, 455);
  vertex(379, 490);
  vertex(350, 455);
  endShape();
  
  strokeJoin(MITER);
  beginShape();
  vertex(323, 455);
  vertex(300, 490);
  vertex(275, 455);
  endShape();
}



