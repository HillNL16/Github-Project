function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(150);
  
  //Left diamond
  strokeWeight(1.5);
  fill(200,0,0);
  quad(100,100, 55,145, 100,200, 125,150);
  strokeWeight(2);
  line(100,200,100,300); 
  
  
  //Cutoff circle
  strokeWeight(1);
  fill(0,26,51);
  arc(300,300,100,100,0, PI + QUARTER_PI, CHORD);
  strokeWeight(4);
  line(300,352,300,400); 
  
  //kite like shape
  strokeWeight(1);
  fill(0,100,0);
  beginShape(TRIANGLE_FAN);
  vertex(300,50);
  vertex(300,15);
  vertex(320,50);
  vertex(300,70);
  vertex(280,50);
  vertex(300,15);
  endShape();
  strokeWeight(2);
  line(300,70,300,120);
  
  //Square
  strokeWeight(3);
  fill(0,0,150,160);
  beginShape();
  vertex(0,275);
  vertex(125,275);
  vertex(125,380);
  vertex(0,380);
  endShape(CLOSE);
  strokeWeight(4);
  line(60,382,60,400);
  
  //Middle ellipse 
  strokeWeight(2);
  fill(204,226,225);
  ellipse(220,200,80,80);
  strokeWeight(3);
  line(220,241,220,380);
  
  //top left ellipse
  strokeWeight(1);
  fill(0,26,100);
  ellipse(130,50,50,50);
  strokeWeight(2);
  line(130,75,130,140);
  
  //Far left ellipse
  strokeWeight(2);
  fill(0,0,200);
  ellipse(35,220,65,65);
  strokeWeight(3);
  line(35,253,35,290);
  
  //ellipse far right
  strokeWeight(2);
  ellipse(350,230,60,60);
  strokeWeight(3);
  line(350,261,350,380);
  
  //top corner ellipse 
  strokeWeight(1);
  fill(204,226,225);
  ellipse(50,50,30,30);
  line(50,65,50,100);
  
}
