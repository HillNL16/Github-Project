var radius = 40;
var x = -radius 
var speed = 2.0; 

function setup() {
  createCanvas(400, 400);
  ellipseMode(RADIUS); 
  frameRate(10);
  
  let eSize = 3;
  let eLoc = 10;
  
  ellipse(eLoc, eLoc, eSize, eSize);
  ellipse(eLoc * 2, eLoc * 2, pow(eSize,2), pow(eSize,2));
  ellipse(eLoc * 4, eLoc * 4, pow(eSize,3), pow(eSize,3));
  ellipse(eLoc * 8, eLoc * 8, pow(eSize,4), pow(eSize,4)); 
  
  angleMode(RADIANS);
  
}

function draw() {
  background(220);
  
  let a = 50;
  let b = 80;
  let c = 150;
  
  //left stack
  strokeWeight(5);
  fill(255,50,0);
  line(a, b, c, b);
  line(a,b + 10, c, b + 10);
  line (a,b +20, c, b + 20);

  
  a=a+c
  b=height-b
  
  //bottom stack
  strokeWeight(2);
  fill(0,0,255);
  line(a,b,c,b);
  line(a,b+10,c,b+10);
  line(a,b+20,c,b+20);
  
  a=a+c
  b=height-b
  
  //right stack
  strokeWeight(3);
  line(a,b,300,b);
  line(a,b+10,300,b+10);
  line(a,b+20,300,b+20);
  
  //motion
  x += speed;
  x + -radius
  arc(x, 60, radius, radius, 0.52, 5.76); 
  
  line(mouseX, 0, mouseX, 400);
  line(0, mouseY, 400, mouseY); 
  
  line(mouseX, mouseY, pmouseX, pmouseY);
  print(pmouseX + '->' + mouseX); 
  
  
  if (mouseY === pmouseY && mouseX === pmouseX)
  print(pmouseY + '->' + mouseY);
  
  fill(200,0,0);
  ellipse(200,200,50,50);
  
  fill(0,200,50);
  ellipse(300,300,25,25);
  
  
}